// backend/index.js
const express = require("express");
const cors = require("cors");
const { Parser } = require("json2csv");

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(express.json());

// ----- Pilot Users & Keys -----
let users = [
  { uid: "0011233180", role: "teacher", user: "Ms. Mendoza", keyId: 101 },
  { uid: "0001203447", role: "teacher", user: "Ms. Gumampo", keyId: 102 },
  { uid: "0005797912", role: "admin", user: "Mr. Gerardo" },
];

let keys = [
  { id: 101, available: true, takenBy: null },
  { id: 102, available: true, takenBy: null },
  { id: 201, available: true, takenBy: null },
];

let logs = [];

// Debug helper
const showUIDs = () => console.log("Registered UIDs:", users.map(u => JSON.stringify(u.uid)));

// ----- Routes -----

// Check RFID card and auto-toggle key taken/returned
app.post("/api/check-rfid", (req, res) => {
  let { uid } = req.body;
  if (!uid) return res.json({ role: "unknown" });

  uid = String(uid).trim(); // Normalize UID
  console.log("Scanned UID:", JSON.stringify(uid));
  showUIDs();

  const user = users.find(u => String(u.uid).trim() === uid);
  console.log("Matched user:", user);

  if (!user) return res.json({ role: "unknown" });

  if (user.role === "teacher") {
    const key = keys.find(k => k.id === user.keyId);

    const action = key && key.available ? "taken" : "returned";
    if (key) {
      key.available = !key.available;
      key.takenBy = key.available ? null : user.user;

      logs.push({
        teacher: user.user,
        keyId: key.id,
        action,
        timestamp: new Date().toISOString(),
      });
    }

    return res.json({
      role: "teacher",
      user: user.user,
      key: key ? { id: key.id } : null,
      action: key ? action : "none",
    });
  }

  if (user.role === "admin") {
    return res.json({ role: "admin", user: user.user });
  }

  return res.json({ role: "unknown" });
});

// ----- Admin manual take/return -----
app.post("/api/key/take", (req, res) => {
  const { keyNumber, adminUser } = req.body;
  const key = keys.find(k => k.id === keyNumber);
  if (!key) return res.status(400).json({ success: false, error: "Invalid key" });
  if (!key.available) return res.status(400).json({ success: false, error: "Key already taken" });

  key.available = false;
  key.takenBy = adminUser;

  logs.push({ teacher: adminUser, keyId: key.id, action: "taken", timestamp: new Date().toISOString() });
  res.json({ success: true });
});

app.post("/api/key/return", (req, res) => {
  const { keyNumber, adminUser } = req.body;
  const key = keys.find(k => k.id === keyNumber);
  if (!key) return res.status(400).json({ success: false, error: "Invalid key" });
  if (key.available) return res.status(400).json({ success: false, error: "Key already returned" });

  key.available = true;
  key.takenBy = null;

  logs.push({ teacher: adminUser, keyId: key.id, action: "returned", timestamp: new Date().toISOString() });
  res.json({ success: true });
});

// Get all keys
app.get("/api/keys", (req, res) => res.json(keys));

// Get all logs
app.get("/api/logs", (req, res) => res.json(logs));

// Export logs as CSV
app.get("/api/logs/export", (req, res) => {
  if (logs.length === 0) return res.status(400).json({ error: "No logs to export" });
  const parser = new Parser();
  const csv = parser.parse(logs);
  res.header("Content-Type", "text/csv");
  res.attachment("logs.csv");
  res.send(csv);
});

// Start server
app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
